package com.appzone.business;
import android.app.Activity; import android.os.Bundle; import android.graphics.Color; import android.content.Intent; import android.net.Uri; import android.view.Gravity; import android.widget.*; import android.graphics.Typeface; import android.graphics.drawable.GradientDrawable;
public class MainActivity extends Activity {
 int navy=Color.rgb(16,35,72), blue=Color.rgb(38,99,235);
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(navy);getWindow().setNavigationBarColor(navy);
 ScrollView sc=new ScrollView(this); LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(dp(22),dp(25),dp(22),dp(25));p.setBackgroundColor(Color.rgb(241,245,249));sc.addView(p);
 TextView logo=t("AppZone",32,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setPadding(0,dp(18),0,dp(18));logo.setBackground(bg(navy,18));p.addView(logo,lp());
 TextView h=t("Apne business ko digital banayein",22,navy,true);h.setGravity(Gravity.CENTER);h.setPadding(0,dp(22),0,dp(12));p.addView(h,lp());
 TextView intro=t("Business app aur online product catalog ke liye rabta karein.",16,Color.DKGRAY,false);intro.setGravity(Gravity.CENTER);intro.setPadding(0,0,0,dp(18));p.addView(intro,lp());
 TextView price=t("Starting price: Rs. 1,700",25,blue,true);price.setGravity(Gravity.CENTER);price.setPadding(0,dp(18),0,dp(18));price.setBackground(bg(Color.WHITE,18));p.addView(price,lp());
 p.addView(t("Available options",19,navy,true),lp());String[] a={"• Product catalog and prices","• Business branding","• WhatsApp inquiry button","• Mobile-friendly design"};for(String s:a){TextView x=t(s,16,Color.DKGRAY,false);x.setPadding(0,dp(9),0,dp(9));p.addView(x,lp());}
 Button btn=new Button(this);btn.setText("WhatsApp par rabta karein");btn.setAllCaps(false);p.addView(btn,lp());btn.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/923044795331?text=Assalam-o-Alaikum%20AppZone"))));
 TextView n=t("WhatsApp: 0304 4795331\nFinal features aur price order se pehle confirm karein.",14,navy,true);n.setGravity(Gravity.CENTER);n.setPadding(0,dp(15),0,0);p.addView(n,lp());setContentView(sc);}
 TextView t(String s,int z,int c,boolean b){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(c);if(b)x.setTypeface(null,Typeface.BOLD);return x;}
 GradientDrawable bg(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 LinearLayout.LayoutParams lp(){return new LinearLayout.LayoutParams(-1,-2);} int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
}
